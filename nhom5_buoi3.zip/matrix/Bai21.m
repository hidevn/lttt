A = [4 1 0 0; 1 4 1 0; 0 1 4 1; 0 0 1 4];
fprintf('Gia tri cua det(A): ');
disp(det(A));