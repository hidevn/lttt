% Ta chung minh bang quy nap
% Voi A la ma tran tam giac tren va khong suy bien, de thay 
% A^(-1) cung la mot ma tran tam giac tren
% gia su dung voi n = k, ta can chung minh no cung dung voi n =k +1
% voi n=k+1, ta co A co dang [A11 A12; 0 a]
% trong do A11 la ma tran tam giac tren kich co k*k, A12 la ma tran kich co
% k*1, a la ma tran kich co 1*1
% tu ket qua cua bai 2.6, ta co
% A^(-1) = [ A11^(-1) -A11^(-1)*A12*1/a; 0 1/a]
% theo gia thiet quy nap ta co A11^(-1) la ma tran tam giac tren 
% => A^(-1) cung la ma tran tam giac tren
% => dieu phai chung minh