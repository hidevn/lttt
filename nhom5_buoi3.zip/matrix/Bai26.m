%xet A * A^(-1) = A^(-1) * A, ta duoc
% A * A^(-1) = [ A11* A11^(-1)  -A12* A22^(-1)+ A12* A22^(-1); 0  A22* A22^(-1)]
%            = [ 1 0; 0 1] = I
% => dieu phai chung minh

