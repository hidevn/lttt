function y = test2(x)
    % TEST2: Ham se thuc hien
    %  1. Tinh y = sin(x) - cos(x).
    %  2. Ve do thi cua y theo doi x.
    y = sin(x) - cos(x);
    plot(x, y);
    % Thu tuc khong co gia tri input output, con ham thi co.
end
